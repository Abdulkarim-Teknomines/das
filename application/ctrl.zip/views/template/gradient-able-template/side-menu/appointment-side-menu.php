<ul class="pcoded-item pcoded-left-item">
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url('schedule_appointment');?>">
            <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Schedule Appointment</span>
            <span class="pcoded-mcaret"></span>
        </a>
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url('edit_appointment');?>">
            <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Edit Appointment</span>
            <span class="pcoded-mcaret"></span>
        </a>
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url('future_appointment');?>">
            <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Future Appointment</span>
            <span class="pcoded-mcaret"></span>
        </a>
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url('appointment_history');?>">
            <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Appointment History</span>
            <span class="pcoded-mcaret"></span>
        </a>
    </li>
</ul>