<ul class="pcoded-item pcoded-left-item">
                                
    <li class="pcoded-hasmenu">
        <a href="javascript:void(0)">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Patient Selection</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="javascript:void(0)">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Type of Work</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="javascript:void(0)">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Lab Address</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="javascript:void(0)">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Location</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="javascript:void(0)">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Lab Charges</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
        
</ul>