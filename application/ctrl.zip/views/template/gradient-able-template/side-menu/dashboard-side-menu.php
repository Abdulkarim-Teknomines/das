    <nav>
    <ul class="pcoded-item pcoded-left-item" item-border="true" item-border-style="none" subitem-border="true">
        <li>
            <a href="<?php echo base_url('dashboard');?>">
                <span class="pcoded-micon"><i class="ti-layers"></i><b>FC</b></span>
                <span class="pcoded-mtext" data-i18n="nav.form-components.main">Dashboard</span>
                <span class="pcoded-mcaret"></span>
            </a>
        </li>
        

    </ul> 

    
</nav>