<style>
    .error{
        color:red;
    }
</style>
<div class="card">
    <div class="card-header">
        <div class="card-block">
            <form method="post" enctype="multipart/form-data">
                <div class="form-group-row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-10">
                        <div class="form-check-inline">
                            <label class="form-check-label">
                            <input type="checkbox" class="form-check-input type_of_work" name="type_of_work" id="type_of_work" value="" >
                            <label class="form-label">Type of Work</label>
                            </label>
                        </div>
                    </div>
                </div>
                </br></br>
                </br></br>
                <div class="row">
                    <div class="col-sm-9">
                        <input type="button" name="submit" class="btn btn-primary text-center m-b-20" value="Collaborate lab link" autocomplete="off">
                    </div>
                    <div class="col-sm-2 text-right">
                    <input type="button" name="submit" class="btn btn-primary text-center m-b-20" value="Submit" autocomplete="off">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
