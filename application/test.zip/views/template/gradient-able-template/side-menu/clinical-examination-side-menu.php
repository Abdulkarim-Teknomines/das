<ul class="pcoded-item pcoded-left-item">
                                
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url()?>medical_history">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Medical History</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url()?>dental_history">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Dental History</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url() ?>clinical_examinator">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Clinical Examinator</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url() ?>investigation">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Investigation</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url() ?>diagnosis">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Diagnosis</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url() ?>treatment_plan">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Treatment Plan</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url() ?>treatment_charges">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Treatment Charges</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
</ul>