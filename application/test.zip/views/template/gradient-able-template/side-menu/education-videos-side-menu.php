<ul class="pcoded-item pcoded-left-item">
    <li class="pcoded-hasmenu">
        <a href="javascript:void(0)">
            <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Education Videos</span>
            <span class="pcoded-mcaret"></span>
        </a>
        <ul class="pcoded-submenu">
            <!-- <li class="">
                <a href="<?php echo base_url()?>education_videos/add_videos">
                    <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                    <span class="pcoded-mtext">Add Videos</span>
                    <span class="pcoded-mcaret"></span>
                </a>
            </li> -->
            <li class="">
                <a href="<?php echo base_url()?>education_videos/list_videos">
                    <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                    <span class="pcoded-mtext">List Videos</span>
                    <span class="pcoded-mcaret"></span>
                </a>
            </li>
        </ul>
    </li>
</ul>