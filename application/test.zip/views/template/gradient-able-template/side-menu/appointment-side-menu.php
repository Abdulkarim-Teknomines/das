<ul class="pcoded-item pcoded-left-item">
   
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url('schedule_appointment');?>">
            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
            <span class="pcoded-mtext"  data-i18n="nnav.basic-components.alert">Schedule Appointment</span>
            <span class="pcoded-mcaret"></span>
        </a>
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url('edit_appointment');?>">
            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
            <span class="pcoded-mtext"  data-i18n="nnav.basic-components.alert">Edit Appointment</span>
            <span class="pcoded-mcaret"></span>
        </a>
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url('future_appointment');?>">
            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
            <span class="pcoded-mtext"  data-i18n="nnav.basic-components.alert">Future Appointment</span>
            <span class="pcoded-mcaret"></span>
        </a>
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url('appointment_history');?>">
            <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
            <span class="pcoded-mtext"  data-i18n="nnav.basic-components.alert">Appointment History</span>
            <span class="pcoded-mcaret"></span>
        </a>
    </li>
</ul>