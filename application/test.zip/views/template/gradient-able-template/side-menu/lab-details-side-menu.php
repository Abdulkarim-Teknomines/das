<ul class="pcoded-item pcoded-left-item">
                                
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url()?>lab_details/patient_selection">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Patient Selection</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url()?>lab_details/type_of_work">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Type of Work</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url()?>lab_details/lab_address">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Lab Address</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url()?>lab_details/location">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Location</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
    <li class="pcoded-hasmenu">
        <a href="<?php echo base_url()?>lab_details/lab_charges">
            <span class="pcoded-micon"></span>
            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Lab Charges</span>
            <span class="pcoded-mcaret"></span>
        </a>
        
    </li>
        
</ul>